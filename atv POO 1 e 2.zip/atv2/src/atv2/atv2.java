package atv2;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.List;
import java.util.Collections;

// Unime - Lauro de Freitas
//Sistemas de Informa��o
//Programa��o Orientada a Objetos II
//Pablo Ricardo
//Samorano Silva -->

public class atv2 {
    public static void main(String[] args) {
    	int qtd;
    	int i;
    //	Menu De Apresenta��o
    	int menu;
    	Scanner teclado;
    	teclado = new Scanner (System.in);
    	//MENU DE OP�OES
        do {
        System.out.println("======== MENU DE OP��ES ========");
        System.out.println("1 � Adicionar participantes");
        System.out.println("2 � Imprimir vetores");
        System.out.println("3 � Eliminar elemento do vetor");
        System.out.println("4 � Pesquisar elemento nos vetores");
        System.out.println("5 � Ordenar os vetores");
        System.out.println("6 � Calcular opera��es matem�ticas");
        System.out.println("7 � Calcular m�todos estat�sticos");
        System.out.println("8 � Total de elementos v�lidos");
        System.out.println("9 - Sair");
        System.out.println("===================================");
        System.out.println("Escolha a sua op��o:");
        menu = teclado.nextInt();
        
        //DECTE��O DE ERRO
        while (menu>9||menu<1){
            System.out.println("Erro, digite uma op��o v�lida:");
            menu = teclado.nextInt();
        }
        
        switch (menu){
            
        //OP��O DO MENU 1
            case 1:
              	
            		//Recebendo valor digitado pelo usuario
                	Scanner input = new Scanner(System.in);
                	System.out.println("Informe a quatidade de participantes que deseja cadastrar:  ");
                	
                	//Adicionando o valor digitado para variavel int qtd
                	qtd=input.nextInt();
                	
                	//Criando o vetor aluno com o tamanho digitado pelo usuario
                	String Alunos[] = new String[qtd];
                	
                	//Inserindo quantidade informada e participantes
                	for( i=0; i<qtd; i++) {
                		System.out.println("Insira o nome do "+(i+1)+"� Participante");
                		Alunos[i] = input.next();
                	}
                	
                	break;	
              	
              //OP��O DO MENU 2    	
            case 2:
              	if (menu==2){
            		//Recebendo valor digitado pelo usuario
              		System.out.println("Voc� selecionou a Op��o 2");
                	
                	break;	
              	}
              //OP��O DO MENU 3   	
            case 3:
              	if (menu==3){
            		//Recebendo valor digitado pelo usuario
              		System.out.println("Voc� selecionou a Op��o 3");
                	
                	break;	
              	}
              //OP��O DO MENU 4
            case 4:
              	if (menu==4){
            		//Recebendo valor digitado pelo usuario
                		System.out.println("Voc� selecionou a op��o 4 ");
                	break;	
              	}
              //OP��O DO MENU 5
            case 5:
              	if (menu==5){
            		//Recebendo valor digitado pelo usuario
              		System.out.println("Voc� selecionou a Op��o 5");
                	
                	break;	
              	}
              //OP��O DO MENU 6
            case 6:
              	if (menu==6){
            		//Recebendo valor digitado pelo usuario
              		System.out.println("Voc� selecionou a Op��o 6");
                	
                	break;	
              	}
              //OP��O DO MENU 7
            case 7:
              	if (menu==7){
            		//Recebendo valor digitado pelo usuario
              		System.out.println("Voc� selecionou a Op��o 7");
                	
                	break;	
              	}
              //OP��O DO MENU 8
            case 8:
              	if (menu==8){
              		//Recebendo valor digitado pelo usuario
                		System.out.println("Voc� selecionou a Op��o 8");
                		
                	break;	
              	}
        }}while(menu!=9);
        	}      
 } 

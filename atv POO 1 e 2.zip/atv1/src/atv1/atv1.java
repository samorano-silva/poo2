package atv1;

import java.util.Scanner;
//Unime - Lauro de Freitas
//Sistemas de Informa��o
//Programa��o Orientada a Objetos II
//Pablo Ricardo
//Samorano Silva -->
public class atv1 {

	public static void main(String[] args) {
		System.out.println("Informe as 3 notas Obtidas neste semestre!");
		Scanner aluno = new Scanner (System.in);
		int nota1;
		int nota2;
		int nota3;
		nota1 = aluno.nextInt();
		nota2 = aluno.nextInt();
		nota3 = aluno.nextInt();
		int media = ((nota1+nota2+nota3)/3);
		System.out.println("Sua Media foi "+ media);
		if(media>=7) {
			System.out.println(" Voc� est� aprovado! Parab�ns!! ");
		}if(media >= 4 && media <7){
			System.out.println(" Voc� est� Reprovado e TEM direito a recupera��o ");
		}if(media <4) {
			System.out.println(" Voc� est� Reprovado"+" SEM direito a Recupera��o ");
		}
	}
	

}
